const char apn[]      = "YourAPN";
const char gprsUser[] = "";
const char gprsPass[] = "";